from django.apps import AppConfig


class CardonalabConfig(AppConfig):
    name = 'cardonalab'
